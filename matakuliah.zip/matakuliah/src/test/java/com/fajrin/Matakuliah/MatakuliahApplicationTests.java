package com.fajrin.Matakuliah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatakuliahApplicationTests {

	@Test
	void contextLoads() {
	}

}
